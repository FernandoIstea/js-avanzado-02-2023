const selectPropiedad = document.querySelector("select#propiedad")
const selectUbicacion = document.querySelector("select#ubicacion")
const inputMetros2 = document.querySelector("input#metros2")

function cargarArrays(select, array) {
    if (array.length > 0) {
        for (elemento of array) {
            select.innerHTML += `<option value="${elemento.factor}">${elemento.tipo}</option>`
        }
    }
} 
cargarArrays(selectPropiedad, datosPropiedad)
cargarArrays(selectUbicacion, datosUbicacion)

