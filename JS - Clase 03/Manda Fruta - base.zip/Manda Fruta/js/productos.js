const productos = [
    {
        "id": 1,
        "imagen": "🍌",
        "nombre": "Bananas",
        "precio": 220
    },
    {
        "id": 2,
        "imagen": "🍎",
        "nombre": "Manzanas R",
        "precio": 200
    },
    {
        "id": 3,
        "imagen": "🍏",
        "nombre": "Manzanas V",
        "precio": 200
    },
    {
        "id": 4,
        "imagen": "🥝",
        "nombre": "Kiwis",
        "precio": 280
    },
    {
        "id": 5,
        "imagen": "🍈",
        "nombre": "Melón",
        "precio": 350
    },
    {
        "id": 6,
        "imagen": "🍍",
        "nombre": "Piñas",
        "precio": 320
    },
    {
        "id": 7,
        "imagen": "🍅",
        "nombre": "Tomates",
        "precio": 140
    },
    {
        "id": 8,
        "imagen": "🍉",
        "nombre": "Sandias",
        "precio": 200
    },
    {
        "id": 9,
        "imagen": "🍑",
        "nombre": "Duraznos",
        "precio": 310
    },
    {
        "id": 10,
        "imagen": "🫐",
        "nombre": "Arandanos",
        "precio": 650
    },
    {
        "id": 11,
        "imagen": "🍇",
        "nombre": "Uvas",
        "precio": 700
    },
    {
        "id": 12,
        "imagen": "🍐",
        "nombre": "Peras",
        "precio": 320
    },
    {
        "id": 13,
        "imagen": "🍒",
        "nombre": "Cerezas",
        "precio": 1100
    },
    {
        "id": 14,
        "imagen": "🍓",
        "nombre": "Frutillas",
        "precio": 600
    },
    {
        "id": 15,
        "imagen": "🍊",
        "nombre": "Mandarinas",
        "precio": 350
    },
    {
        "id": 16,
        "imagen": "🍋",
        "nombre": "Limones",
        "precio": 260
    },
    {
        "id": 17,
        "imagen": "🥥",
        "nombre": "Cocos",
        "precio": 270
    },
    {
        "id": 18,
        "imagen": "🥭",
        "nombre": "Mango",
        "precio": 290
    },
    {
        "id": 19,
        "imagen": "🥑",
        "nombre": "Paltas",
        "precio": 290
    },
    {
        "id": 20,
        "imagen": "🧃",
        "nombre": "Jugos",
        "precio": 195
    },
    {
        "id": 21,
        "imagen": "🥗",
        "nombre": "Macedonia",
        "precio": 390
    }
]